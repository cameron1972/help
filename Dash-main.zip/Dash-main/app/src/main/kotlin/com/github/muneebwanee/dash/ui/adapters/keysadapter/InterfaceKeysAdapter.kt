package com.github.muneebwanee.dash.ui.adapters.keysadapter

import com.github.muneebwanee.dash.ui.adapters.basedapter.InterfaceAdapter

/**
 * Created by muneebwanee on 15/12/20.
 */
interface InterfaceKeysAdapter : InterfaceAdapter