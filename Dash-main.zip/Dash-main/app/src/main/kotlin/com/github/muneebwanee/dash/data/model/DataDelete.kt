package com.github.muneebwanee.dash.data.model

/**
 * Created by muneebwanee on 15/12/20.
 */
data class DataDelete(val key:String,val child:String,val file:String)