package com.github.muneebwanee.dash.services.calls

import com.github.muneebwanee.dash.services.base.InterfaceService

/**
 * Created by muneebwanee on 15/12/20.
 */
interface InterfaceServiceCalls  : InterfaceService{

    fun stopServiceCalls()

}