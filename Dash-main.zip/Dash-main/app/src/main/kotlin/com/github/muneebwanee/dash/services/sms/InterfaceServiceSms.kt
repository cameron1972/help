package com.github.muneebwanee.dash.services.sms

import com.github.muneebwanee.dash.services.base.InterfaceService

/**
 * Created by muneebwanee on 15/12/20.
 */
interface InterfaceServiceSms : InterfaceService {

    fun stopServiceSms()

}