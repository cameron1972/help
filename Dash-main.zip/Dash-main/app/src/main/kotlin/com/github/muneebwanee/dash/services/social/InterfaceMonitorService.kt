package com.github.muneebwanee.dash.services.social

/**
 * Created by muneebwanee on 15/12/20.
 */
interface InterfaceMonitorService {

    fun gerSocialStatus()
    fun setPermission(status:Boolean)

}