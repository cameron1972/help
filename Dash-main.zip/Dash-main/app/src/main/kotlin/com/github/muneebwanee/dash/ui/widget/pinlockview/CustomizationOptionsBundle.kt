package com.github.muneebwanee.dash.ui.widget.pinlockview

/**
 * Created by muneebwanee on 15/12/20.
 */
data class CustomizationOptionsBundle (val textSize: Int, val buttonSize: Int, val deleteButtonSize: Int)

