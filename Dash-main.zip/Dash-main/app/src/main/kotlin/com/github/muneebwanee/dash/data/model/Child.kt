package com.github.muneebwanee.dash.data.model

import java.io.Serializable

/**
 * Created by muneebwanee on 15/12/20.
 */
data class Child(val name:String,val photoUrl:String?,val nameDevice:String) : Serializable