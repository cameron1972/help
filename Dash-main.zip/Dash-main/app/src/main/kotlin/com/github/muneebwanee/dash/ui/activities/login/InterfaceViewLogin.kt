package com.github.muneebwanee.dash.ui.activities.login

import com.github.muneebwanee.dash.ui.activities.base.InterfaceView

/**
 * Created by muneebwanee on 15/12/20.
 */
interface InterfaceViewLogin : InterfaceView