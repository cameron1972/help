package com.github.muneebwanee.dash.di

import javax.inject.Scope

/**
 * Created by muneebwanee on 15/12/20.
 */
@Scope
@Retention(AnnotationRetention.RUNTIME)
annotation class PerService