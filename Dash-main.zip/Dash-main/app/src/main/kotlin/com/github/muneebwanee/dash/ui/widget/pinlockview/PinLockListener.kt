package com.github.muneebwanee.dash.ui.widget.pinlockview

/**
 * Created by muneebwanee on 15/12/20.
 */
interface PinLockListener {
    fun onComplete(pin: String)
}
